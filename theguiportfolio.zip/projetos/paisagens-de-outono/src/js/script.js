function warning() {
    alert("Olá amigo, está página é apenas uma leading page.")
}