# Projeto Engajamento Social
## Um projeto cujo o objetivo é desenvolver possívies soluções, junto a uma determinada comunidade, para alguma de suas dificuldades.


## Nosso projeto foi criado com o entuito de ajudar diversas ONGs e lares de adoção à dar um lar ao animais os quais estão aos tratos deles.
## Como Faço para ajudar uma ONG?
## Simples! Clique no botão doar no canto superior esquerdo da sua tela, escolha a ONG e clique em detalhes, lá você terá informações financeiras da ONG e caso queira doar algo a mais entre em contato com eles!
##