<footer class="background-cinza pt-5 pb-5">
    <address>
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-4 pr-5 pl-5">
                    <address>
                        <h3 class="text-center mb-5">Horário de operação</h3>
                        <p class="paragrafo">Quarta - Segunda</p>
                        <p class="text-muted paragrafo">19:00 - 00:00</p>

                        <h3 class="mt-5 mb-5 mt-5 text-center">Informações de contato</h3>
                        <span class="">Endereço: </span>
                        <p class="paragrafo text-muted">34 Street Name, City Name Here, United States</p>
                        <span class="">Telefone: </span>
                        <p class="paragrafo text-muted"> +55 11 3369-0101</p>
                    </address>
                </div>
                <div class="col-md-4">
                    <h3 class="text-center">Sobre nós</h3>
                    <p class="text-muted paragrafo text-justify indent">Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptatibus et dolor blanditiis consequuntur ex voluptates perspiciatis omnis unde minima expedita.</p>
                </div>
                
                <div class="col-md-4">
                    <h3 class="text-center">Nossas redes sociais</h3>
                </div>
                <div class="col">
                    <p class="text-muted text-center mb-1 mt-5"><small>&copy;Copyright - Guilherme Eduardo Maffei </small></p>
                </div>
            </div>
        </div>
    </address>
</footer>